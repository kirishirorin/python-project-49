### Hexlet tests and linter status:
[![Actions Status](https://github.com/kirishirorin/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/kirishirorin/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/0c5706752162cf3e0645/maintainability)](https://codeclimate.com/github/kirishirorin/python-project-49/maintainability)

brain-even = (https://asciinema.org/a/0MIaG6R08ZGmEFexQ3UGdDmrs)
brain-calc = (https://asciinema.org/a/SusydqLaZ4PaadntlP8fCi30l)
brain-gcd = (https://asciinema.org/a/nCgAvBA0cRQviURbTk7232HHn)
